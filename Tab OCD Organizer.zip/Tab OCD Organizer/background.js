var tabList = [];
var mannualMove = true;

chrome.tabs.query({}, function(tabs){
  tabList = tabs;
  sortTabs();
  mannualMove = true;
});

chrome.tabs.onCreated.addListener(function (tab){
  tabList.push(tab);
  console.log("now tab list:  ", tabList);
  sortTabs();
});

chrome.tabs.onAttached.addListener(function (tabID, attachInfo){
  chrome.tabs.get(tabID, function (tab){
    tabList.push(tab);
    console.log("now tab list:  ", tabList);
    sortTabs();
  });
});

chrome.tabs.onRemoved.addListener(function (tabID, removeInfo){
  for (i = 0; i <= tabList.length - 1; i++){
    if(tabList[i].id == tabID){
      tabList.splice(i,1);
    }
  }
  sortTabs();
});

chrome.tabs.onDetached.addListener(function (tabID, removeInfo){
  for (i = 0; i <= tabList.length - 1; i++){
    if(tabList[i].id == tabID){
      tabList.splice(i,1);
    }
  }
  sortTabs();
});

chrome.tabs.onUpdated.addListener(function (tabID,changeInfo,tab){
  sortTabs();
});

chrome.tabs.onMoved.addListener(function (tabID, moveInfo){
  console.log("moveinfo",moveInfo);
  console.log("from movelistener",mannualMove);
  //sortTabs();
  if(mannualMove === true){
    //alert('I have OCD!! Do not try to mess me up!!');
  } else {
    mannualMove = true;
  }
});

chrome.browserAction.onClicked.addListener(function(tab){
  sortTabs();
});

function sortTabs(){
  var sortedList = tabList.sort(compare);
  for (i = 0; i <= sortedList.length - 1; i++){
    mannualMove = false;
    console.log('here changes');
    chrome.tabs.move(sortedList[i].id, {index: i}, function(tab){});
    mannualMove = false;
  }
  console.log("sorted: ", sortedList);
}

function compare(a, b) {
  const tabA = a.title.toUpperCase();
  const tabB = b.title.toUpperCase();
  
  let comparison = 0;
  if (tabA > tabB) {
    comparison = 1;
  } else if (tabA < tabB) {
    comparison = -1;
  }
  return comparison;
}

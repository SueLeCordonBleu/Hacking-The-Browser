let tabList = [];

getTabList();

function getTabList() {
    chrome.runtime.sendMessage({greeting: "GetTabList"},
        function (response) {
            tabList = response;
            console.log(response);
        });
}
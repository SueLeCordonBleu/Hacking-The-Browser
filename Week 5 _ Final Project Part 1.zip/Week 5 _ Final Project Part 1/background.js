var tabList = [];

chrome.tabs.onCreated.addListener(function (tab){
    tabList.push(tab);
    console.log("now tab list:  ", tabList);
  });


chrome.tabs.onRemoved.addListener(function (tabID, removeInfo){
    for (i = 0; i <= tabList.length - 1; i++){
      if(tabList[i].id == tabID){
        tabList.splice(i,1);
      }
    }
});

chrome.browserAction.onClicked.addListener(function(tab){
    alert("under development!");
  });

chrome.tabs.query({},function(tabs){
    tabList = tabs;
});

chrome.runtime.onMessage.addListener( function(request,sender,sendResponse) {
      if( request.greeting === "GetTabList" )
      {
          var message = "Not set yet";
          message = tabList;
          sendResponse(message);
          console.log(message);
      }
});

function sendResponse(response){
    return response;
}
document.body.style.cursor = "none";
let links = document.getElementsByTagName('a');
for (let link of links){
link.addEventListener("mouseover",(event)=>{
alert("Don’t Touch ME!!");
event.target.setAttribute("style","font-size: 1px")
console.log("touched!")});
}
document.body.addEventListener("click",alert("You’ve lost you mouse!"))